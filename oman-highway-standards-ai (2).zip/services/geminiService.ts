
import { GoogleGenAI } from "@google/genai";
import { OMAN_HIGHWAY_STANDARDS_2017 } from "../knowledgeBase";
import { Message } from "../types";

const SYSTEM_INSTRUCTION = `
You are the "Oman Highway Standards Expert", an AI agent with deep knowledge of the "Sultanate of Oman Ministry of Transport & Communications - Highway Design Standards 2017".
Your primary goal is to help users navigate Volume 3: Standard Specifications for Road & Bridge Construction.

GROUNDING DATA:
${OMAN_HIGHWAY_STANDARDS_2017}

GUIDELINES:
1. Only answer based on the Sultanate of Oman Highway Design Standards 2017.
2. If the user asks something not covered in the standards, politely inform them and offer to help with a related technical topic from the document.
3. Be technical, precise, and authoritative. Reference specific Section numbers when possible (e.g., "According to Section 5.2.3.4...").
4. Provide measurements in metric as specified in the document.
5. If the answer involves a table or specific value (like concrete cover or compaction density), list it clearly.
6. Speak in a professional, engineering-focused tone.
`;

export class GeminiService {
  private ai: any;

  constructor() {
    // API_KEY is fetched from process.env.API_KEY, which is supported by Netlify environment variables
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.error("API_KEY is not defined in the environment variables.");
    }
    this.ai = new GoogleGenAI({ apiKey: apiKey });
  }

  async sendMessage(history: Message[], currentMessage: string): Promise<string> {
    try {
      const contents = history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
      }));

      contents.push({
        role: 'user',
        parts: [{ text: currentMessage }]
      });

      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          temperature: 0.2, // Low temperature for factual accuracy
          topP: 0.95,
          topK: 40,
        },
      });

      const text = response.text;
      if (!text) throw new Error("Empty response from AI");
      
      return text;
    } catch (error) {
      console.error("Gemini API Error:", error);
      throw error;
    }
  }
}
